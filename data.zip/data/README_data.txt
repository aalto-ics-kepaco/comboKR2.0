
=== Explanations of the data files ===

Pre-computed kernel matrices for the input features (cell & drug):
- Kc.npy
- Kd.npy

  -> Gene expression and copy number used as cell line features. For both, RBF kernel is calculated, and kernels are summed together.
  -> MACCS features used for drugs, Tanimoto kernel on them.

Pre-computed empirical features from the kernel matrices (cell & drug):
- Phi_c.npy
- Phi_d.npy

Ids for the input features, the order is the same as the row order in the kernel and feature files
- cellfeat_ids.npy
- drugfeat_ids.npy


Full data identifiers, and training and test sets:
- cdd_full.npy
- cdd_tr.npy
- cdd_tst.npy
  
  -> cdd="cell drug1 drug2"; each fow contains the cell id, and the ids of the two drugs in the combination. "cdd_full.npy" shows the order in which data is given in the numpy arrays, e.g. in the braid function parameters, or measurements. 


Hill and BRAID functions:
- fitted_hills_full.df.pkl (pandas dataframe)
- fitted_braid_params_full.npy (each row contains parameters for one surface, ordered as in "cdd_full.npy"; [E0, E1, E2, E3, h1, h2, C1, C2, kappa])


Measurements:
- measurementsMedian.npy
- conc1.npy
- conc2.npy
